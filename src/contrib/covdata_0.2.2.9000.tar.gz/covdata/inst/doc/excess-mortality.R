## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(tidyverse)
library(covdata)

## ----stmf-example-------------------------------------------------------------
stmf

## ----stmf-figure, fig.height=8, fig.width=12, dpi=100-------------------------
stmf %>%
  filter(sex == "b", country_code == "BEL") %>%
  group_by(year, week) %>%
  mutate(yr_ind = year %in% 2020) %>%
  slice(1) %>%
  ggplot(aes(x = week, y = deaths_total, color = yr_ind, group = year)) + 
  geom_line(size = 0.9) + 
  scale_color_manual(values = c("gray70", "red"), labels = c("2000-2019", "2020")) +
  labs(x = "Week of the Year", 
       y = "Total Deaths", 
       color = "Year",
       title = "Weekly recorded deaths in Belgium, 2000-2020") + 
  theme_minimal() + 
  theme(legend.position = "top")

## ----nytexcess----------------------------------------------------------------
nytexcess

## -----------------------------------------------------------------------------
nytexcess %>%
  filter(placename == "New York City") %>%
  group_by(year, week) %>%
  mutate(yr_ind = year %in% 2020) %>%
  ggplot(aes(x = week, y = deaths, color = yr_ind, group = year)) + 
  geom_line(size = 0.9) + 
  scale_color_manual(values = c("gray70", "red"), labels = c("2017-2019", "2020")) +
  scale_y_continuous(labels = scales::comma) +
  labs(x = "Week of the Year", 
       y = "Total Deaths", 
       color = "Year",
       title = "Weekly recorded deaths in New York City, 2017-2020") + 
  theme_minimal() + 
  theme(legend.position = "top")

