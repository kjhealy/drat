library(testthat)
library(covdata)

test_check("covdata")
