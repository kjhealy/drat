
# gssr 0.1.0

* Prepped for initial release

# gssr 0.0.0.9000

* Fixed errors in the panel tibbles; removed panelr depenedency; added all three-wave panels
* Wrote a short vignette giving an overview of the package.
* Cumulative Data File and Three Wave Panel Data added.
* Added a `NEWS.md` file to track changes to the package.
