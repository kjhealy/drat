library(testthat)
library(covmobility)

test_check("covmobility")
