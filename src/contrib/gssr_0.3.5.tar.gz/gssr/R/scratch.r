# library(tidyverse)
#
# data("gss_panel_doc")
#
#
#
# tmp <- gss_panel_doc %>%
#   mutate(wave = str_extract(id, "_(1|2|3)$"),
#          wave = str_remove(wave, "_"),
#          wave = replace_na(wave, 1),
#          order = 1:nrow(gss_panel_doc)) %>%
#   mutate(id = str_remove(id, "_(1|2|3)$"),
#          description = str_replace(id, "_(1|2|3):", ":")) %>%
#   relocate(wave, id:description, text)
#
# ind <- unique(tmp$id)
#
# tmp <- tmp %>%
#   select(-order)
#
# gss_panel_docw <- tmp %>%
#   pivot_wider(
#     names_from = wave,
#     values_from = c(properties:marginals)
#   ) %>%
#   mutate(id = tolower(id))
