## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(tidyverse)
library(covdata)

## ----stmf-example-------------------------------------------------------------
stmf

## ----stmf-figure, fig.height=8, fig.width=12, dpi=100-------------------------
stmf %>%
  filter(sex == "b", country_code == "BEL") %>%
  group_by(year, week) %>%
  mutate(yr_ind = year %in% 2020) %>%
  slice(1) %>%
  ggplot(aes(x = week, y = deaths_total, color = yr_ind, group = year)) + 
  geom_line(size = 0.9) + 
  scale_color_manual(values = c("gray70", "red"), labels = c("2000-2019", "2020")) +
  labs(x = "Week of the Year", 
       y = "Total Deaths", 
       color = "Year",
       title = "Weekly recorded deaths in Belgium, 2000-2020") + 
  theme_minimal() + 
  theme(legend.position = "top")

## ----nchswdc------------------------------------------------------------------
nchs_wdc

## ----cdcexcessplot, fig.height=14, fig.width=8, dpi=100-----------------------
nchs_wdc %>% 
  filter(jurisdiction %in% c("New York", "New Jersey", "Michigan", "Georgia", "California", "Alabama")) %>%
  filter(cause == "All Cause", year > 2014) %>%
  group_by(jurisdiction, year, week) %>% 
  summarize(deaths = sum(n, na.rm = TRUE)) %>%
  mutate(yr_ind = year %in% 2020) %>%
  filter(!(year == 2020 & week > 35)) %>%
  ggplot(aes(x = week, y = deaths, color = yr_ind, group = year)) + 
  geom_line(size = 0.9) + 
  scale_color_manual(values = c("gray70", "red"), labels = c("2015-2019", "2020")) +
  scale_x_continuous(breaks = c(1, 10, 20, 30, 40, 50), labels = c(1, 10, 20, 30, 40, 50)) + 
  scale_y_continuous(labels = scales::comma) +
  facet_wrap(~ jurisdiction, scales = "free_y", ncol = 1) + 
  labs(x = "Week of the Year", 
       y = "Total Deaths", 
       color = "Years",
       title = "Weekly recorded deaths from all causes", 
       subtitle = "2020 data are for Weeks 1 to 35. Raw Counts, each state has its own y-axis scale.", 
       caption = "Graph: @kjhealy Data: CDC") + 
  theme_minimal() + 
  theme(legend.position = "top")
  

## ----nytexcess----------------------------------------------------------------
nytexcess  

## ----nytexcessplot, fig.height=8, fig.width=12, dpi=100-----------------------
nytexcess %>%
  filter(placename == "New York City") %>%
  group_by(year, week) %>%
  mutate(yr_ind = year %in% 2020) %>%
  ggplot(aes(x = week, y = deaths, color = yr_ind, group = year)) + 
  geom_line(size = 0.9) + 
  scale_color_manual(values = c("gray70", "red"), labels = c("2017-2019", "2020")) +
  scale_y_continuous(labels = scales::comma) +
  labs(x = "Week of the Year", 
       y = "Total Deaths", 
       color = "Year",
       title = "Weekly recorded deaths in New York City, 2017-2020") + 
  theme_minimal() + 
  theme(legend.position = "top")

