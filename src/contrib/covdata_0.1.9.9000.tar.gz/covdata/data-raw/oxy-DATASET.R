## code to prepare covid datasets

library(tidyverse)
library(lubridate)
library(here)
library(janitor)
library(socviz)
library(ggrepel)
library(paletteer)

### Data-getting functions

## Download today's CSV file, saving it to data/ and also read it in
#' @title FUNCTION_TITLE
#' @description FUNCTION_DESCRIPTION
#' @param url PARAM_DESCRIPTION, Default: 'https://opendata.ecdc.europa.eu/covid19/casedistribution/csv'
#' @param date PARAM_DESCRIPTION, Default: lubridate::today()
#' @param writedate PARAM_DESCRIPTION, Default: lubridate::today()
#' @param fname PARAM_DESCRIPTION, Default: 'ecdc-cumulative-'
#' @param ext PARAM_DESCRIPTION, Default: 'csv'
#' @param dest PARAM_DESCRIPTION, Default: 'data-raw/data'
#' @param save_file PARAM_DESCRIPTION, Default: c("y", "n")
#' @return OUTPUT_DESCRIPTION
#' @details DETAILS
#' @examples 
#' \dontrun{
#' if(interactive()){
#'  #EXAMPLE1
#'  }
#' }
#' @seealso 
#'  \code{\link[lubridate]{now}}
#'  \code{\link[fs]{path}},\code{\link[fs]{copy}}
#'  \code{\link[here]{here}}
#'  \code{\link[curl]{curl_download}}
#'  \code{\link[janitor]{clean_names}}
#'  \code{\link[readr]{read_delim}}
#' @rdname get_ecdc_csv
#' @export 
#' @author Kieran Healy
#' @source http://
#' @references 
#' @importFrom lubridate today
#' @importFrom fs path file_copy
#' @importFrom here here
#' @importFrom curl curl_download
#' @importFrom janitor clean_names
#' @importFrom readr read_csv
get_ecdc_csv <- function(url = "https://opendata.ecdc.europa.eu/covid19/casedistribution/csv",
                         date = lubridate::today(),
                         writedate = lubridate::today(),
                         fname = "ecdc-cumulative-",
                         ext = "csv",
                         dest = "data-raw/data",
                         save_file = c("y", "n")) {

  target <- url
  message("target: ", target)
  save_file <- match.arg(save_file)

  destination <- fs::path(here::here("data-raw/data"), paste0(fname, writedate), ext = ext)

  tf <- tempfile(fileext = ext)
  curl::curl_download(target, tf)

  switch(save_file,
    y = fs::file_copy(tf, destination),
    n = NULL)

  janitor::clean_names(readr::read_csv(tf))

}


## Get Daily COVID Tracking Project Data
## form is https://covidtracking.com/api/us/daily.csv

#' @title FUNCTION_TITLE
#' @description FUNCTION_DESCRIPTION
#' @param url PARAM_DESCRIPTION, Default: 'https://covidtracking.com/api/'
#' @param unit PARAM_DESCRIPTION, Default: c("states", "us")
#' @param fname PARAM_DESCRIPTION, Default: '-'
#' @param date PARAM_DESCRIPTION, Default: lubridate::today()
#' @param ext PARAM_DESCRIPTION, Default: 'csv'
#' @param dest PARAM_DESCRIPTION, Default: 'data-raw/data'
#' @param save_file PARAM_DESCRIPTION, Default: c("y", "n")
#' @return OUTPUT_DESCRIPTION
#' @details DETAILS
#' @examples 
#' \dontrun{
#' if(interactive()){
#'  #EXAMPLE1
#'  }
#' }
#' @seealso 
#'  \code{\link[lubridate]{now}}
#'  \code{\link[fs]{path}},\code{\link[fs]{copy}}
#'  \code{\link[here]{here}}
#'  \code{\link[curl]{curl_download}}
#'  \code{\link[janitor]{clean_names}}
#' @rdname get_uscovid_data
#' @export 
#' @author Kieran Healy
#' @source http://
#' @references 
#' @importFrom lubridate today
#' @importFrom fs path file_copy
#' @importFrom here here
#' @importFrom curl curl_download
#' @importFrom janitor clean_names
get_uscovid_data <- function(url = "https://covidtracking.com/api/",
                             unit = c("states", "us"),
                             fname = "-",
                             date = lubridate::today(),
                             ext = "csv",
                             dest = "data-raw/data",
                             save_file = c("y", "n")) {
  unit <- match.arg(unit)
  target <-  paste0(url, unit, "/", "daily.", ext)
  message("target: ", target)

  destination <- fs::path(here::here("data-raw/data"),
                          paste0(unit, "_daily_", date), ext = ext)

  tf <- tempfile(fileext = ext)
  curl::curl_download(target, tf)

  switch(save_file,
         y = fs::file_copy(tf, destination),
         n = NULL)

  janitor::clean_names(read_csv(tf))
}


### Data munging functions

## A useful function from Edward Visel, which does a thing
## with tibbles that in the past I've done variable-by-variable
## using match(), like an animal. The hardest part was
## figuring out that this operation is called a coalescing join
## https://alistaire.rbind.io/blog/coalescing-joins/
#' @title FUNCTION_TITLE
#' @description FUNCTION_DESCRIPTION
#' @param x PARAM_DESCRIPTION
#' @param y PARAM_DESCRIPTION
#' @param by PARAM_DESCRIPTION, Default: NULL
#' @param suffix PARAM_DESCRIPTION, Default: c(".x", ".y")
#' @param join PARAM_DESCRIPTION, Default: dplyr::full_join
#' @param ... PARAM_DESCRIPTION
#' @return OUTPUT_DESCRIPTION
#' @details DETAILS
#' @examples 
#' \dontrun{
#' if(interactive()){
#'  #EXAMPLE1
#'  }
#' }
#' @seealso 
#'  \code{\link[dplyr]{join}},\code{\link[dplyr]{setops}},\code{\link[dplyr]{coalesce}},\code{\link[dplyr]{bind}}
#'  \code{\link[purrr]{map}}
#' @rdname coalesce_join
#' @export 
#' @author Kieran Healy
#' @source http://
#' @references 
#' @importFrom dplyr full_join union coalesce bind_cols
#' @importFrom purrr map_dfc
coalesce_join <- function(x, y,
                          by = NULL, suffix = c(".x", ".y"),
                          join = dplyr::full_join, ...) {
  joined <- join(x, y, by = by, suffix = suffix, ...)
  # names of desired output
  cols <- dplyr::union(names(x), names(y))

  to_coalesce <- names(joined)[!names(joined) %in% cols]
  suffix_used <- suffix[ifelse(endsWith(to_coalesce, suffix[1]), 1, 2)]
  # remove suffixes and deduplicate
  to_coalesce <- unique(substr(
    to_coalesce,
    1,
    nchar(to_coalesce) - nchar(suffix_used)
  ))

  coalesced <- purrr::map_dfc(to_coalesce, ~dplyr::coalesce(
    joined[[paste0(.x, suffix[1])]],
    joined[[paste0(.x, suffix[2])]]
  ))
  names(coalesced) <- to_coalesce

  dplyr::bind_cols(joined, coalesced)[cols]
}

### Country Codes

## ----iso-country-codes-------------------------------------------------------------------------------------------
## Country codes. The ECDC does not quite use standard codes for countries
## These are the iso2 and iso3 codes, plus some convenient groupings for
## possible use later
#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 249 rows and 2 variables:
#' \describe{
#'   \item{\code{iso3}}{character COLUMN_DESCRIPTION}
#'   \item{\code{cname}}{character COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"iso3_cnames"
iso3_cnames <- read_csv("data-raw/data/countries_iso3.csv")
#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 249 rows and 2 variables:
#' \describe{
#'   \item{\code{iso2}}{character COLUMN_DESCRIPTION}
#'   \item{\code{iso3}}{character COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"iso2_to_iso3"
iso2_to_iso3 <- read_csv("data-raw/data/iso2_to_iso3.csv")

#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 249 rows and 3 variables:
#' \describe{
#'   \item{\code{iso3}}{character COLUMN_DESCRIPTION}
#'   \item{\code{cname}}{character COLUMN_DESCRIPTION}
#'   \item{\code{iso2}}{character COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"cname_table"
cname_table <- left_join(iso3_cnames, iso2_to_iso3)

cname_table

eu <- c("AUT", "BEL", "BGR", "HRV", "CYP", "CZE", "DNK", "EST", "FIN", "FRA",
        "DEU", "GRC", "HUN", "IRL", "ITA", "LVA", "LTU", "LUX", "MLT", "NLD",
        "POL", "PRT", "ROU", "SVK", "SVN", "ESP", "SWE", "GBR")

europe <- c("ALB", "AND", "AUT", "BLR", "BEL", "BIH", "BGR", "HRV", "CYP", "CZE",
            "DNK", "EST", "FRO", "FIN", "FRA", "DEU", "GIB", "GRC", "HUN", "ISL",
            "IRL", "ITA", "LVA", "LIE", "LTU", "LUX", "MKD", "MLT", "MDA", "MCO",
            "NLD", "NOR", "POL", "PRT", "ROU", "RUS", "SMR", "SRB", "SVK", "SVN",
            "ESP", "SWE", "CHE", "UKR", "GBR", "VAT", "RSB", "IMN", "MNE")

north_america <- c("AIA", "ATG", "ABW", "BHS", "BRB", "BLZ", "BMU", "VGB", "CAN", "CYM",
                   "CRI", "CUB", "CUW", "DMA", "DOM", "SLV", "GRL", "GRD", "GLP", "GTM",
                   "HTI", "HND", "JAM", "MTQ", "MEX", "SPM", "MSR", "ANT", "KNA", "NIC",
                   "PAN", "PRI", "KNA", "LCA", "SPM", "VCT", "TTO", "TCA", "VIR", "USA",
                   "SXM")

south_america <- c("ARG", "BOL", "BRA", "CHL", "COL", "ECU", "FLK", "GUF", "GUY", "PRY",
                   "PER", "SUR", "URY", "VEN")


africa <- c("DZA", "AGO", "SHN", "BEN", "BWA", "BFA", "BDI", "CMR", "CPV", "CAF",
            "TCD", "COM", "COG", "DJI", "EGY", "GNQ", "ERI", "ETH", "GAB", "GMB",
            "GHA", "GNB", "GIN", "CIV", "KEN", "LSO", "LBR", "LBY", "MDG", "MWI",
            "MLI", "MRT", "MUS", "MYT", "MAR", "MOZ", "NAM", "NER", "NGA", "STP",
            "REU", "RWA", "STP", "SEN", "SYC", "SLE", "SOM", "ZAF", "SHN", "SDN",
            "SWZ", "TZA", "TGO", "TUN", "UGA", "COD", "ZMB", "TZA", "ZWE", "SSD",
            "COD")

asia <- c("AFG", "ARM", "AZE", "BHR", "BGD", "BTN", "BRN", "KHM", "CHN", "CXR",
          "CCK", "IOT", "GEO", "HKG", "IND", "IDN", "IRN", "IRQ", "ISR", "JPN",
          "JOR", "KAZ", "PRK", "KOR", "KWT", "KGZ", "LAO", "LBN", "MAC", "MYS",
          "MDV", "MNG", "MMR", "NPL", "OMN", "PAK", "PHL", "QAT", "SAU", "SGP",
          "LKA", "SYR", "TWN", "TJK", "THA", "TUR", "TKM", "ARE", "UZB", "VNM",
          "YEM", "PSE")

oceania <- c("ASM", "AUS", "NZL", "COK", "FJI", "PYF", "GUM", "KIR", "MNP", "MHL",
             "FSM", "UMI", "NRU", "NCL", "NZL", "NIU", "NFK", "PLW", "PNG", "MNP",
             "SLB", "TKL", "TON", "TUV", "VUT", "UMI", "WLF", "WSM", "TLS")


### Get and clean cross-national data
#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 12186 rows and 11 variables:
#' \describe{
#'   \item{\code{date_rep}}{character COLUMN_DESCRIPTION}
#'   \item{\code{day}}{double COLUMN_DESCRIPTION}
#'   \item{\code{month}}{double COLUMN_DESCRIPTION}
#'   \item{\code{year}}{double COLUMN_DESCRIPTION}
#'   \item{\code{cases}}{double COLUMN_DESCRIPTION}
#'   \item{\code{deaths}}{double COLUMN_DESCRIPTION}
#'   \item{\code{countries_and_territories}}{character COLUMN_DESCRIPTION}
#'   \item{\code{geo_id}}{character COLUMN_DESCRIPTION}
#'   \item{\code{countryterritory_code}}{character COLUMN_DESCRIPTION}
#'   \item{\code{pop_data2018}}{double COLUMN_DESCRIPTION}
#'   \item{\code{continent_exp}}{character COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"covid_raw"
covid_raw <- get_ecdc_csv(save = "n")

covid_raw

#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 12186 rows and 15 variables:
#' \describe{
#'   \item{\code{date_rep}}{character COLUMN_DESCRIPTION}
#'   \item{\code{day}}{double COLUMN_DESCRIPTION}
#'   \item{\code{month}}{double COLUMN_DESCRIPTION}
#'   \item{\code{year}}{double COLUMN_DESCRIPTION}
#'   \item{\code{cases}}{double COLUMN_DESCRIPTION}
#'   \item{\code{deaths}}{double COLUMN_DESCRIPTION}
#'   \item{\code{countries_and_territories}}{character COLUMN_DESCRIPTION}
#'   \item{\code{geo_id}}{character COLUMN_DESCRIPTION}
#'   \item{\code{countryterritory_code}}{character COLUMN_DESCRIPTION}
#'   \item{\code{pop_data2018}}{double COLUMN_DESCRIPTION}
#'   \item{\code{continent_exp}}{character COLUMN_DESCRIPTION}
#'   \item{\code{date}}{double COLUMN_DESCRIPTION}
#'   \item{\code{iso2}}{character COLUMN_DESCRIPTION}
#'   \item{\code{iso3}}{character COLUMN_DESCRIPTION}
#'   \item{\code{cname}}{character COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"covid"
covid <- covid_raw %>%
  mutate(date = lubridate::dmy(date_rep),
         iso2 = geo_id)

## merge in the iso country names
#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 12186 rows and 15 variables:
#' \describe{
#'   \item{\code{date_rep}}{character COLUMN_DESCRIPTION}
#'   \item{\code{day}}{double COLUMN_DESCRIPTION}
#'   \item{\code{month}}{double COLUMN_DESCRIPTION}
#'   \item{\code{year}}{double COLUMN_DESCRIPTION}
#'   \item{\code{cases}}{double COLUMN_DESCRIPTION}
#'   \item{\code{deaths}}{double COLUMN_DESCRIPTION}
#'   \item{\code{countries_and_territories}}{character COLUMN_DESCRIPTION}
#'   \item{\code{geo_id}}{character COLUMN_DESCRIPTION}
#'   \item{\code{countryterritory_code}}{character COLUMN_DESCRIPTION}
#'   \item{\code{pop_data2018}}{double COLUMN_DESCRIPTION}
#'   \item{\code{continent_exp}}{character COLUMN_DESCRIPTION}
#'   \item{\code{date}}{double COLUMN_DESCRIPTION}
#'   \item{\code{iso2}}{character COLUMN_DESCRIPTION}
#'   \item{\code{iso3}}{character COLUMN_DESCRIPTION}
#'   \item{\code{cname}}{character COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"covid"
covid <- left_join(covid, cname_table)

## A few ECDC country codes are non-iso, notably the UK
anti_join(covid, cname_table) %>%
  select(geo_id, countries_and_territories, iso2, iso3, cname) %>%
  distinct()

## A small crosswalk file that we'll coalesce into the missing values
## We need to specify the na explicity because the xwalk file has Namibia
## as a country -- i.e. country code = string literal "NA"
#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 4 rows and 3 variables:
#' \describe{
#'   \item{\code{geo_id}}{character COLUMN_DESCRIPTION}
#'   \item{\code{iso3}}{character COLUMN_DESCRIPTION}
#'   \item{\code{cname}}{character COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"cname_xwalk"
cname_xwalk <- read_csv("data-raw/data/ecdc_to_iso2_xwalk.csv",
                        na = "")

cname_xwalk

#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 12186 rows and 15 variables:
#' \describe{
#'   \item{\code{date_rep}}{character COLUMN_DESCRIPTION}
#'   \item{\code{day}}{double COLUMN_DESCRIPTION}
#'   \item{\code{month}}{double COLUMN_DESCRIPTION}
#'   \item{\code{year}}{double COLUMN_DESCRIPTION}
#'   \item{\code{cases}}{double COLUMN_DESCRIPTION}
#'   \item{\code{deaths}}{double COLUMN_DESCRIPTION}
#'   \item{\code{countries_and_territories}}{character COLUMN_DESCRIPTION}
#'   \item{\code{geo_id}}{character COLUMN_DESCRIPTION}
#'   \item{\code{countryterritory_code}}{character COLUMN_DESCRIPTION}
#'   \item{\code{pop_data2018}}{double COLUMN_DESCRIPTION}
#'   \item{\code{continent_exp}}{character COLUMN_DESCRIPTION}
#'   \item{\code{date}}{double COLUMN_DESCRIPTION}
#'   \item{\code{iso2}}{character COLUMN_DESCRIPTION}
#'   \item{\code{iso3}}{character COLUMN_DESCRIPTION}
#'   \item{\code{cname}}{character COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"covid"
covid <- coalesce_join(covid, cname_xwalk,
                       by = "geo_id", join = dplyr::left_join)

## Take a look again
anti_join(covid, cname_table) %>%
  select(geo_id, countries_and_territories, iso2, iso3, cname) %>%
  distinct()

#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 12122 rows and 8 variables:
#' \describe{
#'   \item{\code{date}}{double COLUMN_DESCRIPTION}
#'   \item{\code{cname}}{character COLUMN_DESCRIPTION}
#'   \item{\code{iso3}}{character COLUMN_DESCRIPTION}
#'   \item{\code{cases}}{double COLUMN_DESCRIPTION}
#'   \item{\code{deaths}}{double COLUMN_DESCRIPTION}
#'   \item{\code{pop_2018}}{double COLUMN_DESCRIPTION}
#'   \item{\code{cu_cases}}{double COLUMN_DESCRIPTION}
#'   \item{\code{cu_deaths}}{double COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"covnat"
covnat <- covid %>%
  select(date, cname, iso3, cases, deaths, pop_data2018) %>%
  rename(pop_2018 = pop_data2018) %>%
  drop_na(iso3) %>%
  group_by(iso3) %>%
  arrange(date) %>%
  mutate(cu_cases = cumsum(cases),
         cu_deaths = cumsum(deaths))

covnat ## Data object

### Get US Data from the COVID Tracking Project
## US state data
#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 2564 rows and 25 variables:
#' \describe{
#'   \item{\code{date}}{double COLUMN_DESCRIPTION}
#'   \item{\code{state}}{character COLUMN_DESCRIPTION}
#'   \item{\code{positive}}{double COLUMN_DESCRIPTION}
#'   \item{\code{negative}}{double COLUMN_DESCRIPTION}
#'   \item{\code{pending}}{double COLUMN_DESCRIPTION}
#'   \item{\code{hospitalized_currently}}{double COLUMN_DESCRIPTION}
#'   \item{\code{hospitalized_cumulative}}{double COLUMN_DESCRIPTION}
#'   \item{\code{in_icu_currently}}{double COLUMN_DESCRIPTION}
#'   \item{\code{in_icu_cumulative}}{double COLUMN_DESCRIPTION}
#'   \item{\code{on_ventilator_currently}}{double COLUMN_DESCRIPTION}
#'   \item{\code{on_ventilator_cumulative}}{double COLUMN_DESCRIPTION}
#'   \item{\code{recovered}}{double COLUMN_DESCRIPTION}
#'   \item{\code{hash}}{character COLUMN_DESCRIPTION}
#'   \item{\code{date_checked}}{double COLUMN_DESCRIPTION}
#'   \item{\code{death}}{double COLUMN_DESCRIPTION}
#'   \item{\code{hospitalized}}{double COLUMN_DESCRIPTION}
#'   \item{\code{total}}{double COLUMN_DESCRIPTION}
#'   \item{\code{total_test_results}}{double COLUMN_DESCRIPTION}
#'   \item{\code{pos_neg}}{double COLUMN_DESCRIPTION}
#'   \item{\code{fips}}{character COLUMN_DESCRIPTION}
#'   \item{\code{death_increase}}{double COLUMN_DESCRIPTION}
#'   \item{\code{hospitalized_increase}}{double COLUMN_DESCRIPTION}
#'   \item{\code{negative_increase}}{double COLUMN_DESCRIPTION}
#'   \item{\code{positive_increase}}{double COLUMN_DESCRIPTION}
#'   \item{\code{total_test_results_increase}}{double COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"cov_us_raw"
cov_us_raw <- get_uscovid_data(save_file = "n")

#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 46152 rows and 5 variables:
#' \describe{
#'   \item{\code{date}}{double COLUMN_DESCRIPTION}
#'   \item{\code{state}}{character COLUMN_DESCRIPTION}
#'   \item{\code{fips}}{character COLUMN_DESCRIPTION}
#'   \item{\code{measure}}{character COLUMN_DESCRIPTION}
#'   \item{\code{count}}{double COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"covus"
covus <- cov_us_raw %>%
  mutate(date = lubridate::ymd(date)) %>%
  select(-hash, -date_checked) %>%
  select(date, state, fips, everything()) %>%
  pivot_longer(positive:total_test_results_increase,
               names_to = "measure", values_to = "count") %>%
  filter(measure %nin% c("pos_neg", "total"))

covus

### Get US county data from the NYT

## NYT county data
#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 59249 rows and 6 variables:
#' \describe{
#'   \item{\code{date}}{double COLUMN_DESCRIPTION}
#'   \item{\code{county}}{character COLUMN_DESCRIPTION}
#'   \item{\code{state}}{character COLUMN_DESCRIPTION}
#'   \item{\code{fips}}{character COLUMN_DESCRIPTION}
#'   \item{\code{cases}}{double COLUMN_DESCRIPTION}
#'   \item{\code{deaths}}{double COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"nytcovcounty"
nytcovcounty <- read_csv("data-raw/data/nyt-us-counties.csv")

### NYT state data
#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 2385 rows and 5 variables:
#' \describe{
#'   \item{\code{date}}{double COLUMN_DESCRIPTION}
#'   \item{\code{state}}{character COLUMN_DESCRIPTION}
#'   \item{\code{fips}}{character COLUMN_DESCRIPTION}
#'   \item{\code{cases}}{double COLUMN_DESCRIPTION}
#'   \item{\code{deaths}}{double COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"nytcovstate"
nytcovstate <- read_csv("data-raw/data/nyt-us-states.csv")

### NYt national (US only) data
#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 85 rows and 3 variables:
#' \describe{
#'   \item{\code{date}}{double COLUMN_DESCRIPTION}
#'   \item{\code{cases}}{double COLUMN_DESCRIPTION}
#'   \item{\code{deaths}}{double COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"nytcovus"
nytcovus <- read_csv("data-raw/data/nyt-us.csv")


## Get CDC Surveillance Data
## Courtesy of Bob Rudis's cdccovidview package
#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 4590 rows and 8 variables:
#' \describe{
#'   \item{\code{catchment}}{character COLUMN_DESCRIPTION}
#'   \item{\code{network}}{character COLUMN_DESCRIPTION}
#'   \item{\code{year}}{character COLUMN_DESCRIPTION}
#'   \item{\code{mmwr_year}}{character COLUMN_DESCRIPTION}
#'   \item{\code{mmwr_week}}{character COLUMN_DESCRIPTION}
#'   \item{\code{age_category}}{character COLUMN_DESCRIPTION}
#'   \item{\code{cumulative_rate}}{double COLUMN_DESCRIPTION}
#'   \item{\code{weekly_rate}}{double COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"cdc_hospitalizations"
cdc_hospitalizations <- cdccovidview::laboratory_confirmed_hospitalizations()
cdc_death_counts <- cdccovidview::provisional_death_counts()

#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 12 rows and 11 variables:
#' \describe{
#'   \item{\code{week}}{character COLUMN_DESCRIPTION}
#'   \item{\code{covid_deaths}}{character COLUMN_DESCRIPTION}
#'   \item{\code{total_deaths}}{double COLUMN_DESCRIPTION}
#'   \item{\code{percent_expected_deaths}}{character COLUMN_DESCRIPTION}
#'   \item{\code{pneumonia_deaths}}{character COLUMN_DESCRIPTION}
#'   \item{\code{pneumonia_and_covid_deaths}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{all_influenza_deaths_j09_j11}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{NA}}{double COLUMN_DESCRIPTION}
#'   \item{\code{NA}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{NA}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{NA}}{integer COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"cdc_deaths_by_week"
cdc_deaths_by_week <- cdc_death_counts$by_week
#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 12 rows and 11 variables:
#' \describe{
#'   \item{\code{age_group}}{character COLUMN_DESCRIPTION}
#'   \item{\code{covid_deaths}}{character COLUMN_DESCRIPTION}
#'   \item{\code{total_deaths}}{character COLUMN_DESCRIPTION}
#'   \item{\code{percent_expected_deaths}}{character COLUMN_DESCRIPTION}
#'   \item{\code{pneumonia_deaths}}{character COLUMN_DESCRIPTION}
#'   \item{\code{pneumonia_and_covid_deaths}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{all_influenza_deaths_j09_j11}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{NA}}{double COLUMN_DESCRIPTION}
#'   \item{\code{NA}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{NA}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{NA}}{integer COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"cdc_deaths_by_age"
cdc_deaths_by_age <- cdc_death_counts$by_age
#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 4 rows and 11 variables:
#' \describe{
#'   \item{\code{sex}}{character COLUMN_DESCRIPTION}
#'   \item{\code{covid_deaths}}{character COLUMN_DESCRIPTION}
#'   \item{\code{total_deaths}}{character COLUMN_DESCRIPTION}
#'   \item{\code{percent_expected_deaths}}{character COLUMN_DESCRIPTION}
#'   \item{\code{pneumonia_deaths}}{character COLUMN_DESCRIPTION}
#'   \item{\code{pneumonia_and_covid_deaths}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{all_influenza_deaths_j09_j11}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{NA}}{double COLUMN_DESCRIPTION}
#'   \item{\code{NA}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{NA}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{NA}}{integer COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"cdc_deaths_by_sex"
cdc_deaths_by_sex <- cdc_death_counts$by_sex
#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 54 rows and 11 variables:
#' \describe{
#'   \item{\code{state}}{character COLUMN_DESCRIPTION}
#'   \item{\code{covid_deaths}}{character COLUMN_DESCRIPTION}
#'   \item{\code{total_deaths}}{character COLUMN_DESCRIPTION}
#'   \item{\code{percent_expected_deaths}}{character COLUMN_DESCRIPTION}
#'   \item{\code{pneumonia_deaths}}{character COLUMN_DESCRIPTION}
#'   \item{\code{pneumonia_and_covid_deaths}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{all_influenza_deaths_j09_j11}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{NA}}{double COLUMN_DESCRIPTION}
#'   \item{\code{NA}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{NA}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{NA}}{integer COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"cdc_deaths_by_state"
cdc_deaths_by_state <- cdc_death_counts$by_state

#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 17 rows and 2 variables:
#' \describe{
#'   \item{\code{name}}{character COLUMN_DESCRIPTION}
#'   \item{\code{area}}{character COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"cdc_catchments"
cdc_catchments <- cdccovidview::surveillance_areas()

#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 54 rows and 9 variables:
#' \describe{
#'   \item{\code{week}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{num_fac}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{total_ed_visits}}{character COLUMN_DESCRIPTION}
#'   \item{\code{visits}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{pct_visits}}{double COLUMN_DESCRIPTION}
#'   \item{\code{visit_type}}{character COLUMN_DESCRIPTION}
#'   \item{\code{region}}{character COLUMN_DESCRIPTION}
#'   \item{\code{source}}{character COLUMN_DESCRIPTION}
#'   \item{\code{year}}{integer COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"nssp_covid_er_nat"
nssp_covid_er_nat <- cdccovidview::nssp_er_visits_national()
#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 538 rows and 9 variables:
#' \describe{
#'   \item{\code{week}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{num_fac}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{total_ed_visits}}{character COLUMN_DESCRIPTION}
#'   \item{\code{visits}}{integer COLUMN_DESCRIPTION}
#'   \item{\code{pct_visits}}{double COLUMN_DESCRIPTION}
#'   \item{\code{visit_type}}{character COLUMN_DESCRIPTION}
#'   \item{\code{region}}{character COLUMN_DESCRIPTION}
#'   \item{\code{source}}{character COLUMN_DESCRIPTION}
#'   \item{\code{year}}{integer COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"nssp_covid_er_reg"
nssp_covid_er_reg <- cdccovidview::nssp_er_visits_regional()

## Apple Mobility Data
#' @title DATASET_TITLE
#' @description DATASET_DESCRIPTION
#' @format A data frame with 38710 rows and 5 variables:
#' \describe{
#'   \item{\code{geo_type}}{character COLUMN_DESCRIPTION}
#'   \item{\code{region}}{character COLUMN_DESCRIPTION}
#'   \item{\code{transportation_type}}{character COLUMN_DESCRIPTION}
#'   \item{\code{date}}{double COLUMN_DESCRIPTION}
#'   \item{\code{index}}{double COLUMN_DESCRIPTION} 
#'}
#' @details DETAILS
#' @author Kieran Healy
#' @source http://
#' @references 
"apple_mobility"
apple_mobility <- read_csv("data-raw/data/applemobilitytrends-2020-04-19.csv") %>%
  pivot_longer(`2020-01-13`:`2020-04-19`, names_to = "date", values_to = "index") %>%
  mutate(date = as_date(date))

## write data
usethis::use_data(covnat, overwrite = TRUE)
usethis::use_data(covus, overwrite = TRUE)

usethis::use_data(nytcovcounty, overwrite = TRUE)
usethis::use_data(nytcovstate, overwrite = TRUE)
usethis::use_data(nytcovus, overwrite = TRUE)


usethis::use_data(cdc_hospitalizations, overwrite = TRUE)
usethis::use_data(cdc_deaths_by_week, overwrite = TRUE)
usethis::use_data(cdc_deaths_by_age, overwrite = TRUE)
usethis::use_data(cdc_deaths_by_sex, overwrite = TRUE)
usethis::use_data(cdc_deaths_by_state, overwrite = TRUE)
usethis::use_data(cdc_catchments, overwrite = TRUE)
usethis::use_data(nssp_covid_er_nat, overwrite = TRUE)
usethis::use_data(nssp_covid_er_reg, overwrite = TRUE)

usethis::use_data(apple_mobility, overwrite = TRUE)


