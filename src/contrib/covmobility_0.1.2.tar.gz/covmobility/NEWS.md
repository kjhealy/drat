# covmobility 0.1

- This is the first release of this data package. It inculdes `apple_mobility` and `google_mobility` datasets that are in `covdata` package. As the size of these datasets continues to grow, I've moved them to their own package and will likely remove one or both of them from `covdata` soon.
