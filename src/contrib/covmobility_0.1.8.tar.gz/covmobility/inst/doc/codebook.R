## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  cache = TRUE,
  collapse = TRUE,
  cache.lazy = FALSE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(covmobility)

## -----------------------------------------------------------------------------
data(apple_mobility)
skimr::skim(apple_mobility)

## -----------------------------------------------------------------------------
data(google_mobility)
skimr::skim(google_mobility)

## -----------------------------------------------------------------------------
data(country_codes)
country_codes %>%
  dplyr::ungroup() %>%
  skimr::skim()

